#!/bin/bash


#提示要发布的分支地址
read -t 60 -p "请输入分支名称:" name
echo -e "\n"
curl http://192.168.248.112:8080/job/supplier_app_js/buildWithParameters\?token\=hhhhhhhhhh\&BranchName\=origin/$name
echo "正在发布:$name 请稍等或前往Jenkins 查看 http://192.168.248.112:8080 "
