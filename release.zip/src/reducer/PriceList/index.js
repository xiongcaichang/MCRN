import { handleActions } from 'redux-actions';

const PriceList = handleActions({
  PRICE_LIST_UPDATAE(preData, action){
    return {
      ...action.payload,
    };
  },
}, {
  list:[
    {
      productName: 'SSU商品名称',
      newestPrice: '100',
      time: '2018.07.24 23:00'
    },
    {
      productName: 'SSU商品名称',
      newestPrice: '100',
      time: '2018.07.24 23:00'
    },    {
      productName: 'SSU商品名称',
      newestPrice: '100',
      time: '2018.07.24 23:00'
    },    {
      productName: 'SSU商品名称',
      newestPrice: '100',
      time: '2018.07.24 23:00'
    }

  ]
});

export default PriceList;
