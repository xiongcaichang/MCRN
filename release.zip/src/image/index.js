  export const LOGO_IMG = require('./mine/logo.png');
  export const PWD_IMG = require('./mine/password.png');
  export const USR_IMG = require('./mine/user.png');
  export const NAV_BACK_IMG = require('./Nav/back.png');
  export const SEARCH_ICON = require('./public/search.png');
  export const AVATAR_DEFAULT = require('./mine/avatar_default.png');
  export const ABOUT = require('./mine/about.png');
  export const MINE = require('./mine/mine.png');
  export const PRINTER = require('./mine/printer.png');
  export const SHIELD = require('./mine/shield.png');
  export const LG_ARROW = require('./mine/right-arrow-lightgray.png');
  export const PRICE_LIST = require('./menu/pricelist.png');
  export const SELECTED = require('./public/selected.png');
  export const UNSELECTED = require('./public/unselect.png');
  export const MESSAGE_NAV = require('./Nav/message.png');


