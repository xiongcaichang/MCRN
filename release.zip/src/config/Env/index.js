const env = {
    prod: {
        USER_CENTER: 'http://prod.xxxx.com/uc/',
        BI_SERVICE: 'http://prod.xxxx.com/bi/'
    },
    beta1: {
        USER_CENTER: 'http://beta1.xxxx.com/uc/',
        BI_SERVICE: 'http://beta1.xxxx.com/bi/'
    },
    beta2: {
        USER_CENTER: 'http://beta2.xxxx.com/uc/',
        BI_SERVICE: 'http://beta2.xxxx.com/bi/'
    },
    dev1: {
        USER_CENTER: 'http://dev1.xxxx.com/uc/',
        BI_SERVICE: 'http://dev1.xxxx.com/bi/'
    },
    dev2: {
        USER_CENTER: 'http://dev2.xxxx.com/uc/',
        BI_SERVICE: 'http://dev2.xxxx.com/bi/'
    },
    dev3: {
        USER_CENTER: 'http://dev3.xxxx.com/uc/',
        BI_SERVICE: 'http://dev3.xxxx.com/bi/'
    }
}
export default env;