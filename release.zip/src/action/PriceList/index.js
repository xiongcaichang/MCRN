import { createAsyncAction } from 'redux-action-tools';
import loading from 'MCUtil/loading'
import 'MCUtil/md5';


const testFunc = (data) => new Promise(function(resolve, reject) {
  setTimeout(()=> {
    resolve(data)
  }, 1000)
});

export default {
  updatePriceList: createAsyncAction('PRICE_LIST_UPDATAE',testFunc),
};
