import EStyleSheet from 'react-native-extended-stylesheet';
import { DEVICE_WIDTH, fixSize } from '@MCRN/device';

const styles = EStyleSheet.create({
    container: {
      flex: 1,
      height: fixSize(240),
      backgroundColor: '#FFF',
      marginBottom: 10,
    },
    wapper: {
        flex: 1,
        flexDirection: 'column',
        paddingLeft: fixSize(15),
        paddingRight: fixSize(15),
        paddingTop: fixSize(20),
        paddingBottom: fixSize(16),
      },
      pname: {
        fontSize: 16,
        fontWeight: '500',
        color: '#2F2C2C',
      },
      cityName: {
        paddingTop: fixSize(14),
        fontSize: 14,
        color: '#847F7E',
      },
      priceName: {
        paddingTop: fixSize(5),
        paddingBottom: fixSize(5),
        fontSize: 14,
        color: '#847F7E',
      },
      priceTime: {
        fontSize: 14,
        color: '#847F7E',
      },
      rightWapper: {
        flex: 0,
        width: fixSize(100),
        flexDirection: 'column',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
      },
      inlineText: {
        flex: 1,
        flexDirection: 'row',
        marginBottom: fixSize(10),
        marginTop: fixSize(10),
      },
      lowPrice: {
        flex:1,
        fontSize: 14,
        color: '#847F7E',
      },
      highPrice: {
        flex:1,
        fontSize: 14,
        color: '#847F7E',
      },
      priceName: {
        fontSize: 14,
        fontWeight: '400',
        color: '#2F2C2C',
      },

      priceWrapper: {
        flex: 1,
        justifyContent:'flex-start',
        alignItems:'center',
        flexDirection: 'row',
        paddingLeft: fixSize(15),
        paddingRight: fixSize(15),
        paddingTop: fixSize(20),
        paddingBottom: fixSize(20),
        height: fixSize(60),
        backgroundColor: '#F8F8F8',
      },

      priceNum: {
        fontSize: 18,
        fontWeight: '500',
        color: '#2F2C2C',
      },
      price:{
        flex: 1,
        height: 30,
        fontSize: fixSize(22),
      },
      quoteBtn: {
        backgroundColor: '#EA5D4F',
        marginTop: fixSize(10),
        width: fixSize(DEVICE_WIDTH - 30),
        height: fixSize(44),
        borderRadius: fixSize(3),

      }
  });


  export default styles;
  