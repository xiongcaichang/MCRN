/**
 * 报价输入
 */

import React  from 'react';
import {
  View,
  Text,
  TextInput,
} from 'react-native';
import PropTypes from 'prop-types';
import Btn from 'rnx-ui/Btn'
import style from './style.js';


function PriceAccessoryView(props) {
  return (
    <View style={style.container}>
    <View style={style.wapper}>
        <Text style={style.pname}>{props.item.productName || 'SSU商品名称'} </Text>
        <Text style={style.cityName}>城市: 北京  </Text>
        <View style={style.inlineText}>
          <Text style={style.lowPrice}>历史最低: ￥0.90</Text>
          <Text style={style.highPrice}>历史最低: ￥1.20</Text>
        </View>
        <View style={style.priceWrapper}>
          <Text style={style.priceName}>报价</Text>
          <Text style={style.priceNum}>￥</Text>
          <TextInput editable={false} placeholder="0.00" style={style.price}  value={props.price}/>
        </View>
      <Btn onPress={() => props.onQuotedBtnClick(props.item)} style={style.quoteBtn}>提交</Btn>
    </View>
    </View>
  );
}

PriceAccessoryView.propTypes = {
  onQuotedBtnClick: PropTypes.func,
  item: PropTypes.object
};
PriceAccessoryView.defaultProps = {
  onQuotedBtnClick: () => {},
  item: {}
};

export default PriceAccessoryView;
