import EStyleSheet from 'react-native-extended-stylesheet';
import { fixSize } from '@MCRN/device';

const styles = EStyleSheet.create({
    container: {
      flex: 1,
      height: fixSize(100),
      backgroundColor: '#FFF',
      marginBottom: 10,
    },
    wapper: {
        flex: 1,
        flexDirection: 'row',
        paddingLeft: fixSize(15),
        paddingRight: fixSize(15),
        paddingTop: fixSize(20),
        paddingBottom: fixSize(16),
      },
      leftWapper: {
        flex: 1,
  
      },
      pname: {
        fontSize: 16,
        fontWeight: '500',
        color: '#2F2C2C',
      },
      priceName: {
        paddingTop: fixSize(10),
        paddingBottom: fixSize(10),
        fontSize: 14,
        color: '#847F7E',
      },
      priceTime: {
        fontSize: 14,
        color: '#847F7E',
      },
      rightWapper: {
        flex: 0,
        width: fixSize(100),
        flexDirection: 'column',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
      },
      quoteBtn: {
        backgroundColor: '#EA5D4F',
        width: fixSize(70),
        height: fixSize(30),
        borderRadius: fixSize(3),

      }
  });


  export default styles;
  