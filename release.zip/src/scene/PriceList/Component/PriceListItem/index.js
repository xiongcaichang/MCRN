/**
 * 报价列表item
 */

import React  from 'react';
import {
  View,
  Text,
} from 'react-native';
import PropTypes from 'prop-types';
import Btn from 'rnx-ui/Btn'
import style from './style';


function PriceListItem(props) {
  return (
    <View style={style.container}>
    <View style={style.wapper}>
      <View style={style.leftWapper}>

        <Text style={style.pname}>{props.item.productName} </Text>
        <Text style={style.priceName}>最新报价:  {props.item.newestPrice}</Text>
        <Text style={style.priceTime}>报价时间: {props.item.time}</Text>
      </View>
      <View style={style.rightWapper}>
      <Btn onPress={() => props.onQuotedBtnClick(props.item)} style={style.quoteBtn}>报价</Btn>
      </View>
    </View>
    

    </View>
  );
}

PriceListItem.propTypes = {
  onQuotedBtnClick: PropTypes.func,
};
PriceListItem.defaultProps = {
  onQuotedBtnClick: () => {}
};

export default PriceListItem;
