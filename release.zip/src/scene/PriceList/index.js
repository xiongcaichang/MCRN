import React, { Component } from 'react';
import {View, TextInput, FlatList} from 'react-native';
import mconnect from '@MCRN/mconnect';
import screen from '@MCRN/screen';
import { Page, NavBar, Body, SearchBar } from 'MCComponent'
import Overlay from 'rnx-ui/Overlay'
import style from './style';
import PriceListItem  from './Component/PriceListItem'
import PriceAccessoryView  from './Component/PriceAccessoryView'

const InputAccessoryView = require('InputAccessoryView')

@mconnect({listData: 'PriceList.list'}) @screen
export default class PriceList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      text: '',
      overlayVisiable: false,
    };
  }

  onQuotedBtnClick = (item) => {
    this.setState({
      overlayVisiable: true,
    })
   

  }

  onBlur = (item) => {
    this.setState({
      overlayVisiable: false,
    })
  }
  
  renderItem = (item) => {
    return <PriceListItem
              onQuotedBtnClick={this.onQuotedBtnClick}
              {...item} 
              />
  }

  onListRefresh = (item) => {
  }

  
  render() {
    const inputAccessoryViewID = "hiddenID";
    return ( 
    <Page style={style.container}>
    <Overlay onPress={() => this.showFlag.blur()} visible={this.state.overlayVisiable} style={{zIndex: 999}}/>
      <NavBar title="商品报价" leftEvent={this.goBack} />
      <Body noPadding>
        <SearchBar placeholder="请输入商品名称"/>
        <FlatList
              refreshing={false}
              style={{flex: 1}}
              data={this.props.listData}
              onRefresh={()=> {}}
              keyExtractor={(item, index) => index.toString()}
              renderItem={this.renderItem}
            />
           {this.state.overlayVisiable &&<TextInput
            ref={(ref) => this.showFlag = ref}
            inputAccessoryViewID={inputAccessoryViewID}
            onChangeText={text => this.setState({text})}
            autoFocus={true}
            value={this.state.text}
            onBlur={this.onBlur}
            keyboardType="decimal-pad"
          />}
       {this.state.overlayVisiable &&<InputAccessoryView nativeID={inputAccessoryViewID}>
        <View style={[style.accessoryWapper,{opacity: this.state.overlayVisiable ? 1: 0 }]}>
        <PriceAccessoryView price={this.state.text}/>
        </View>
     </InputAccessoryView>}
      </Body>
    </Page>
    );
  }
}
