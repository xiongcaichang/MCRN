/**
 * HomeScene
 * @authors 杨景帅 (yangjingshuai@meicai.cn)
 * @date    2018-07-09 16:56:47
 * @version $Id$
 */

import React, { Component } from 'react';
import { Text, View, StatusBar,Image } from 'react-native';
import navigation from '@MCRN/navigation'
import { DEVICE_WIDTH, DEVICE_HEIGHT } from '@MCRN/device'
import style from './style';
import SplashScreen from 'react-native-splash-screen'

export default class LaunchScene extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
   
    setTimeout(() => {
      SplashScreen.hide();
      navigation.resetRoute('LoginScene')
    }, 2000);
  }

  render() {
    return (
      <View style={style.container}>
        <StatusBar hidden animated={false}/>
      </View>
    );
  }
}
